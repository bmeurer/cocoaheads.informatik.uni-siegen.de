//
//  IsaDemoAppDelegate_iPad.m
//  IsaDemo
//
//  Created by Julian Dax on 09.07.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "IsaDemoAppDelegate_iPad.h"

@implementation IsaDemoAppDelegate_iPad

- (void)dealloc
{
	[super dealloc];
}

@end
