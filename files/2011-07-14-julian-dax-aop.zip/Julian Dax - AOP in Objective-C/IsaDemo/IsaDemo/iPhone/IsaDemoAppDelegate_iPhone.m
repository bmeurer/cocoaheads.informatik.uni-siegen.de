//
//  IsaDemoAppDelegate_iPhone.m
//  IsaDemo
//
//  Created by Julian Dax on 09.07.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "IsaDemoAppDelegate_iPhone.h"

@implementation IsaDemoAppDelegate_iPhone

- (void)dealloc
{
	[super dealloc];
}

@end
