//
//  IsaDemoAppDelegate_iPhone.h
//  IsaDemo
//
//  Created by Julian Dax on 09.07.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IsaDemoAppDelegate.h"

@interface IsaDemoAppDelegate_iPhone : IsaDemoAppDelegate {
    
}

@end
