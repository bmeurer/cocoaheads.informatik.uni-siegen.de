//
//  ISAClass.m
//  IsaDemo
//
//  Created by Julian Dax on 09.07.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ISAClass.h"


@implementation ISAClass

-(void)setIsa:(Class)newIsa{
    isa = newIsa;
}

-(void)sayHelloWorld{
    NSLog(@"%@", @"Hello World");
}

@end
