//
//  ISAClass.h
//  IsaDemo
//
//  Created by Julian Dax on 09.07.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ISAClass : NSObject {
    
}
-(void)setIsa:(Class)newIsa;
-(void)sayHelloWorld;

@end
