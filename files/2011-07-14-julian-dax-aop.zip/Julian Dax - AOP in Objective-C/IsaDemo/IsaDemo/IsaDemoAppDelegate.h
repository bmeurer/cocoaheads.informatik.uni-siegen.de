//
//  IsaDemoAppDelegate.h
//  IsaDemo
//
//  Created by Julian Dax on 09.07.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IsaDemoAppDelegate : NSObject <UIApplicationDelegate> {

}

-(void)sayHelloWorld;

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
