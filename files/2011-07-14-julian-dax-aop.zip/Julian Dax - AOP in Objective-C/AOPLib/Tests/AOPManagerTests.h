//
//  AOPManagerTests.h
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <GHUnitIOS/GHUnit.h>
#import "AOPManager.h"
#import "AOPAspect.h"
#import "AOPTestClass.h"


@interface AOPManagerTests : GHTestCase {
    AOPManager* testManager;
}

@end
