//
//  AOPTestClass.h
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface AOPTestClass : NSObject {
    
}

-(void)sayHello;
-(void)sayGoodbye;
-(void)sayWord:(NSString*)word;
-(NSString*)complicatedMehtod:(int)number andString:(NSString*)testString andFloat:(float) testFloat;


@end
