//
//  AOPManagerTests.m
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AOPManagerTests.h"


@implementation AOPManagerTests


- (void)setUp {
    testManager = [[AOPManager alloc] init];
}

- (void)tearDown {
    [testManager release];
    testManager = nil;
}
-(void)testSimpleInsert{
    Aspect loggingAspect = ^(NSInvocation* invocation,NSMutableDictionary* data){NSLog(@"Added an object!"); return (id)nil;};
    [testManager insertAspect:loggingAspect beforeMethod:@selector(addObject:) ofClass:[NSMutableArray class]];
    
    NSMutableArray* array = [NSMutableArray array];
    [array addObject:@"Hello World!"];
}

-(void)testWithParametre{
    Aspect testAspect = ^(NSInvocation* invocation, NSMutableDictionary* data){NSLog(@"hello form aspect");return (id)nil;};
    [testManager insertAspect:testAspect beforeMethod:@selector(sayWord:) ofClass:[AOPTestClass class]];
    AOPTestClass* testInstance = [[AOPTestClass alloc] init];
    [testInstance sayWord:@"Test"];
    [testInstance release];

}

-(void)testComplicated{
    Aspect testAspect = ^(NSInvocation* invocation, NSMutableDictionary* data){NSLog(@"hello form aspect");return (id)nil;};
    [testManager insertAspect:testAspect beforeMethod:@selector(complicatedMehtod:andString:andFloat:) ofClass:[AOPTestClass class]];
    AOPTestClass* testInstance = [[AOPTestClass alloc] init];
    [testInstance complicatedMehtod:5 andString:@"lala" andFloat:3.3f];
    [testInstance release];
}

-(void)testSharedState{
    Aspect timerAdviceBefore = ^(NSInvocation* inv, NSMutableDictionary* dict){
       NSDate* date = [NSDate date];
       [dict setValue:date forKey:@"date"];
       return (id)nil;
    };
    
    Aspect timerAdviceAfter = ^(NSInvocation* inv, NSMutableDictionary* dict){
        NSDate* startDate = (NSDate*)[dict objectForKey:@"date"];
        NSTimeInterval interval = [startDate timeIntervalSinceNow] * -1000.0;
        NSLog(@"Time: %f", interval);
        
        return (id)nil;  
    };
    
    [testManager insertAspect:timerAdviceBefore beforeMethod:@selector(sayHello) ofClass:[AOPTestClass class]];
    [testManager insertAspect:timerAdviceAfter afterMethod:@selector(sayHello) ofClass:[AOPTestClass class]];
    AOPTestClass* testInstance = [[AOPTestClass alloc] init];
    [testInstance sayHello];
    [testInstance release];
}

@end
