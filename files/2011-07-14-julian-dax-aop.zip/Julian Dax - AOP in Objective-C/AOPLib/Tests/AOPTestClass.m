//
//  AOPTestClass.m
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AOPTestClass.h"


@implementation AOPTestClass


-(void)sayHello{
    NSLog(@"Hello!");
}
-(void)sayGoodbye{
    NSLog(@"Goodbye");
}

-(void)sayWord:(NSString*)word{
    NSLog(@"%@",word);
}

-(NSString*)complicatedMehtod:(int)number andString:(NSString*)testString andFloat:(float) testFloat {
    NSLog(@"Numer %i String %@ Float %f", number, testString, testFloat);
    return @"CompliatedReturnSting";
}


@end
