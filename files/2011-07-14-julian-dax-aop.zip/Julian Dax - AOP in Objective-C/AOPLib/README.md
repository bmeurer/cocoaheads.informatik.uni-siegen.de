Overview
========

AOPLib is a aspect oriented programming framework for Objective C. It can be
easly integrated into existing code as it does not require you to create
the objects which have pontcuts in them using the framework. It supports 
the advices 'before', 'after' and 'instead' and also allows surrounding
aspects by sharing data between the 'before' and 'after' aspects. It is 
implemented using method swizzling and the 
[libffi](https://github.com/atgreen/libffi) framework. This makes method
calling faster then proxy-based AOP, since message passing is not neccessarry.
Aspects are represented as blocks, which makes them easy to define. 

AOPLib does currently not support searching for pointcuts using regular
expressions. The user has to explicitly tell the framework where the aspects
should be added. That means each join point is a pointcut. I'm planning to add
dynamic pointcut resolution in future versions.

Due to the implementation using method swizzling, AOPLib does not - and never
will - support C structs as arguments to pointcuts. There are ways around that
problem but they all semm very hacky to me.

Setting Up AOPLib
==============

TODO: Upload the compile framework to the download section.

Using AOPLib
=========

Getting Started
---------------

The code below shows how to define an apect and add it to a method.
```objective-c
    //First, set up an AOPManager
    AOPManager* testManager = [[AOPManager alloc] init];
    //Define an aspect
    Aspect loggingAspect = ^(NSInvocation* invocation,NSMutableDictionary* data){NSLog(@"Added an object!"); return (id)nil;};
    //Use the AOPManager to add the aspect before the method "addObejct:"
    [testManager insertAspect:loggingAspect beforeMethod:@selector(addObject:) ofClass:[NSMutableArray class]];
    NSMutableArray* array = [NSMutableArray array];
    [array addObject:@"Hello World!"]; 
```



Initializer And Setter Injection
--------------------------------

If you want OIL to use a different init method, or if you want to set certain instance variables directly after creation of the object, you need to provide an *OILInitBlock*. Each class can have one init block. Init blocks are executed, when `getInstance` is called. They do all initialisation and return the object.

    //Set up an OILContainer
    OILContainer* myContainer = [[OILContainer alloc] init];
    //This tells OILContainer what to do if the user wants a new instance of 'MyClass':
    [myContainer setInitializer:^(OILContainer container){
        id myObject = [[MyClass alloc] initWithNumber:5]; //calling custom init method
        myObject.attribute = @"test"; //setting an inistance variable

    } forClass:[MyClass class]];
    
    //Get a new instance of MyClass. It will be initialized with the init block which we just provided.
    MyClass *myObjec = [myContainer getInstance:[MyClass class]];

Init blocks take an OILContainer and return the Object which they initialized.

Creating Object Hierarchies
---------------------------

In many cases, an object created by OIL is based on other objects which themselves need to be instantiated by OIL. As an example, consider the following Classes:

**Author.h**

    @interface Author : NSObject {
       NSString* firstName;
       NSString* lastName;
    }

    -(Author*)initWithFirstName:(NSString*)theFistName andLastName:(NSString*)theLastName;
    @end

**Book.h**

    @interface Book : NSObject {
        NSString* title;
        Author* author;
    }
    -(Book*)initWithTitle:(NSString*)theTitle andAuthor:(Author*)theAuthor;
    @end
    
The class 'Book' depends on 'Author'. In order to let OIL create both the book and the author with their designated initializers, you need to call OIL in the initialization code like this:

    //Set up an OILConteainer
    OILContainer* myContainer = [[OILContainer alloc] init];
    //Set initializer for 'Author'
    [myContainer setInitializer:^(OILContainer* cont){
         return (id)[[Author alloc] initWithFirstName:@"Herbert George" andLastName:@"Wells"];
    } forClass:[Author class]];
    //Set initializer for 'Book'  
    [myContainer setInitializer:
     ^(OILContainer* cont){
         return (id)[[Book alloc] initWithTitle:@"The Time Machine" andAuthor:[cont getInstance:[Author class]]];
    } forClass:[Book class]];
    //Create book instance
    Book* myBook = [testContainer getInstance:[Book class]];

OIL now creates the book with the author HG Wells.

Binding Protocols To Classes
----------------------------

It is possible to bind a protocol to a certain class which implements the protocol like this:

    //Set up an OILConteainer
    OILContainer* myContainer = [[OILContainer alloc] init];
    Protocol* person = @protocol(Person); //'Person' is a protocoll which is implemented by 'Author'
    [myContainer setInitializer:^(OILContainer* cont){return (id)[[Author alloc] initWithFirstName:@"HG" andLastName:@"Wells"];} forProtocol:person];
    id<Person> myPerson = [myContainer getInstanceForProtcol:person]; //myPerson is an instance of 'Author'
   

Singletons
----------

You can mark a certain class or protocol as singleton, by calling the *markClassAsSingleton* or *markProtocolAsSingleton* methods like so:

    [myContainer markClassAsSingleton:[MyClass class]];
    [myContainer markProtocolAsSingleton:@protocol(MyProtocoll)];

Singletons are created lazily, as soon as they are needed.
