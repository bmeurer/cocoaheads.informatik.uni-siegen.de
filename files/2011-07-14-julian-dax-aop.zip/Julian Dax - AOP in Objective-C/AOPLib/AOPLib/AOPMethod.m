//
//  AOPMethod.m
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AOPMethod.h"


@implementation AOPMethod

@synthesize methodPointer, before, after,signature;

-(id)initWithMethodPointer:(IMP) pointer andSignature:(NSMethodSignature*)sig{
    self = [super init];
    if (self) {
        methodPointer = pointer;
        signature = sig;
        before = [[NSMutableArray alloc] init];
        after = [[NSMutableArray alloc] init];
    }
    return self;
}
- (void)dealloc {
    [before release];
    [after release];
    [super dealloc];
}


-(void)addAdviceBefore:(Aspect) theAspect {
    [before addObject:theAspect];
}

-(void)addAdviceAfter:(Aspect) theAspect {
    [after addObject:theAspect];
}

@end
