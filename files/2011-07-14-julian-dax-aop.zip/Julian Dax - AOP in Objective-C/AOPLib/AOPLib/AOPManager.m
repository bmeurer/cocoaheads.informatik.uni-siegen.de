//
//  AOPManager.m
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AOPManager.h"


@interface AOPManager (private)
-(NSMethodSignature*)signatureForMethod:(Method)theMethod;


@end

@implementation AOPManager



- (id)init {
    self = [super init];
    if (self) {
        classes = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (void)dealloc {
    [classes release];
    [super dealloc];
}

//! This function calls all aspects and the original function 
/*!
 This fuction is called every time a method with aspects is called.
 
 @param self The object which "owns" the pointcut
 @param _cmd The selector of the pointcut
 @param ... all the other arguments passed to the method
 */ 

id replacementFunction(id self, SEL _cmd,...){
    //Receive method infos
    AOPClass* originalClass = [classes objectForKey:[self class]];
    AOPMethod* originalMethod = [originalClass methodForSelector:_cmd];
    NSMethodSignature* signature = [originalMethod signature];
    unsigned long numberOfArguments = [signature numberOfArguments];
    unsigned long framesize = [signature frameLength];
    NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
    
    //prepare libffi variables
    ffi_cif cif;
    void** values = malloc(framesize);
    ffi_type* argTypes[numberOfArguments];
    
    //Star var_list after _cmd
    va_list varArgs;
    va_start(varArgs, _cmd);
    
    //The firtst two arguments are always self and _cmd, both of type pointer
    [invocation setArgument:self atIndex:0];
    [invocation setArgument:_cmd atIndex:1];
    
    argTypes[0] = &ffi_type_pointer;
    argTypes[1] = &ffi_type_pointer;
    
    values[0] = &self;
    values[1] = &_cmd;
    
    //this iterates over the thid and all following arguments
    for(int i = 2; i < numberOfArguments; i++){ 
        //get the fist char of the encoded type of the current argument
        const char* encoding  = [signature getArgumentTypeAtIndex:i];
        //this swiches on the type of the argument and recieves the value of
        //the argument form the stack usind va_arg
        
        // See http://developer.apple.com/library/mac/#documentation/Cocoa/Conceptual/ObjCRuntimeGuide/Articles/ocrtTypeEncodings.html
        switch(encoding[0]){
            case 'f': 
                argTypes[i] = &ffi_type_float;
                double floatType = va_arg(varArgs, double);
                values[i] = &floatType;
                break;
            case 'd': 
                argTypes[i] = &ffi_type_double;
                double doubleType = va_arg(varArgs, double);
                values[i] = &doubleType;
                break;
            case 'B': 
                argTypes[i] = &ffi_type_uchar;
                int boolType = va_arg(varArgs, int);
                values[i] = &boolType;
                break;
            case 'C': 
                argTypes[i] = &ffi_type_uchar;
                int ucharType = va_arg(varArgs, int);
                values[i] = &ucharType;
                break;
            case 'c': 
                argTypes[i] = &ffi_type_schar;
                int charType = va_arg(varArgs, int);
                values[i] = &charType;
                break;
            case 'S': 
                argTypes[i] = &ffi_type_ushort;
                int ushortType = va_arg(varArgs, int);
                values[i] = &ushortType;
                break;
            case 's': 
                argTypes[i] = &ffi_type_sshort;
                int shortType = va_arg(varArgs, int);
                values[i] = &shortType;
                break;
            case 'I': 
                argTypes[i] = &ffi_type_uint;
                unsigned int unitType = va_arg(varArgs, unsigned int);
                values[i] = &unitType;
                break;
            case 'i': 
                argTypes[i] = &ffi_type_sint;
                int intType = va_arg(varArgs, int);
                values[i] = &intType;
                break;
            case 'L': 
                argTypes[i] = &ffi_type_ulong;
                unsigned long ulongType = va_arg(varArgs, unsigned long);
                values[i] = &ulongType;
                break;
            case 'l': 
                argTypes[i] = &ffi_type_slong;
                long longType = va_arg(varArgs, long);
                values[i] = &longType;
                break;
            case 'Q': 
                argTypes[i] = &ffi_type_uint64;
                long long longlongType = va_arg(varArgs, long long);
                values[i] = &longlongType;
                break;
            case 'q': 
                argTypes[i] = &ffi_type_sint64;
                unsigned long long ulonglongType = va_arg(varArgs, unsigned long long);
                values[i] = &ulonglongType;
                break;
            case '@': 
                argTypes[i] = &ffi_type_pointer;
                id objType = va_arg(varArgs, id);
                values[i] = &objType;
                break;
            case '#': 
                argTypes[i] = &ffi_type_pointer;
                Class classType = va_arg(varArgs, Class);
                values[i] = &classType;
                break;
            case '*': 
                argTypes[i] = &ffi_type_pointer;
                char* chrPointerType = va_arg(varArgs, char*);
                values[i] = &chrPointerType;
                break;
            case ':': // Argument is a selector
                argTypes[i]= &ffi_type_pointer;
                SEL selectorType = va_arg(varArgs, SEL);
                values[i] = &selectorType;
                break;
            case '^': 
                argTypes[i] = &ffi_type_pointer;
                id pointerType = va_arg(varArgs, id);
                values[i] = &pointerType;
                break;
            default:
                NSAssert(YES, @"AOPLip cannot handle the method %@, as one of it's parameters has an unspupported type.", NSStringFromSelector(_cmd));
        }
        [invocation setArgument:values[i] atIndex:i];
        
    }
    //prepare the cif structure for the ffi_call
    int status =  ffi_prep_cif(&cif, FFI_DEFAULT_ABI, numberOfArguments, &ffi_type_pointer, argTypes);
    if (status != FFI_OK) {
        NSLog (@"failed to prepare cif structure");
    }

    id returnVal = nil;    
    IMP original = [originalMethod methodPointer]; //the original method which is later on called
    NSMutableDictionary* aspectData = [NSMutableDictionary dictionary]; //aspects can share data between each other using this dict
    

    for(Aspect current in [originalMethod before]){ 
        returnVal = current(invocation, aspectData);
        if(returnVal) { 
            //if the aspect returns something other then nil,
            //execution of the original method and of all other aspects is skipped.
            //This can be used to replace a method
            free(values);
            return returnVal;
        }
    }
    ffi_call(&cif, FFI_FN(original) , &returnVal, values);
    for(Aspect current in [originalMethod after]){
        id tmp = current(invocation, aspectData);
        if(tmp) //if the adive returns soeting this is the retun value of the method call
            returnVal = tmp;
    }
    
    free(values);

    return returnVal;
}

-(void)insertAspect:(Aspect)theAspect beforeMethod:(SEL)method ofClass:(Class)class{
    //Save Aspect infos for later retrival
       
    //Find or create an AOPClass for the class
    AOPClass* aopClass = [classes objectForKey:class];
    if (!aopClass) {
        aopClass = [[AOPClass alloc] init];
        [classes setObject:aopClass forKey:class];
        [aopClass release];
    }
     //Find or create an AOPMethod for the method
    AOPMethod* aopMethod = [aopClass methodForSelector:method];
    if (!aopMethod) { //in this case, there is no AOPMethod for the current method
        //Create a new AOPMethod
        IMP oldImplementation = class_getMethodImplementation_stret(class, method);
        Method oldMethod = class_getInstanceMethod(class, method);
        NSMethodSignature* signature = [self signatureForMethod:oldMethod];
        aopMethod = [[AOPMethod alloc] initWithMethodPointer:oldImplementation andSignature:signature];
        NSMutableString* argumentTypes = [NSMutableString string];
        for(int i=0;i<[signature numberOfArguments];i++){
            NSString* currentType = [NSString stringWithCString:[signature getArgumentTypeAtIndex:i] encoding:NSASCIIStringEncoding];
            [argumentTypes appendString:currentType];
        }
        
        [aopClass addMethod:aopMethod forSelector:method];
        class_replaceMethod(class,method,replacementFunction,[argumentTypes cStringUsingEncoding:NSASCIIStringEncoding]);

        [aopMethod release];
    }
    [aopMethod addAdviceBefore:theAspect];
    
    
}

-(void)insertAspect:(Aspect)theAspect afterMethod:(SEL)method ofClass:(Class)class{
    //Save Aspect infos for later retrival
    
    //Find or create an AOPClass for the class
    AOPClass* aopClass = [classes objectForKey:class];
    if (!aopClass) {
        aopClass = [[AOPClass alloc] init];
        [classes setObject:aopClass forKey:class];
        [aopClass release];
    }
    //Find or create an AOPMethod for the method
    AOPMethod* aopMethod = [aopClass methodForSelector:method];
    if (!aopMethod) { //in this case, there is no AOPMethod for the current method
        //Create a new AOPMethod
        IMP oldImplementation = class_getMethodImplementation_stret(class, method);
        Method oldMethod = class_getInstanceMethod(class, method);
        aopMethod = [[AOPMethod alloc] initWithMethodPointer:oldImplementation andSignature:[self signatureForMethod:oldMethod]];
        [aopClass addMethod:aopMethod forSelector:method];
        class_replaceMethod(class,method,replacementFunction,method_getTypeEncoding(oldMethod));
        [aopMethod release];

    }
    [aopMethod addAdviceAfter:theAspect];
    
   
}



@end

@implementation AOPManager (private)

-(NSMethodSignature*)signatureForMethod:(Method)theMethod {
    const char* encoding = method_getTypeEncoding(theMethod);
    return [NSMethodSignature signatureWithObjCTypes:encoding];    
}





@end

