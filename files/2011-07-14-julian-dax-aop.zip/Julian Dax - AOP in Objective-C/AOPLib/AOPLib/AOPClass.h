//
//  AOPClass.h
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 Julian Dax. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "AOPMethod.h"

@interface AOPClass : NSObject {
    NSMutableDictionary* methods;
}

-(void)addMethod:(AOPMethod*)method forSelector:(SEL)selector;
-(AOPMethod*)methodForSelector:(SEL)selector;

@end
