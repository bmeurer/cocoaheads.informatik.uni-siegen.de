//
//  AOPAspect.h
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 Julian Dax. All rights reserved.
//

//! This block represents an aspect
/*!
 @param invocation This NSInvocation contains all the paramteters
        which the original method was called with. Including self and _cmd.
 @param adivceData This dictionary is passed to all aspects which are executen 
        in the same pointcut. It can be used to exchange information between the aspects.
 @return Aspects should return (id)nil in most cases. If you return anything other than nil,
        this means that the execution of the original method is prevented and the method retuns
        the retund value of the aspect.
 */ 

typedef id (^Aspect)(NSInvocation* invocation, NSMutableDictionary* adivceData);
