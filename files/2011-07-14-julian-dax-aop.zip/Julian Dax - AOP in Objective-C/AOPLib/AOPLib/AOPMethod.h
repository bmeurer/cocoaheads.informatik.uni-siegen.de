//
//  AOPMethod.h
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AOPAspect.h"


@interface AOPMethod : NSObject {
    IMP methodPointer;
    NSMutableArray* before;
    NSMutableArray* after;
    NSMethodSignature* signature;
}

@property (nonatomic,readonly) IMP methodPointer;
@property (nonatomic,retain) NSMutableArray* before;
@property (nonatomic,retain) NSMutableArray* after;
@property (nonatomic,readonly) NSMethodSignature* signature;


-(id)initWithMethodPointer:(IMP) pointer andSignature:(NSMethodSignature*)sig;
-(void)addAdviceBefore:(Aspect) theAspect;
-(void)addAdviceAfter:(Aspect) theAspect;

@end
