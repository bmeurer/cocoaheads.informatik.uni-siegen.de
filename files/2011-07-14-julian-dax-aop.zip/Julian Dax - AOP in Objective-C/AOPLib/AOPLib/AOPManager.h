//
//  AOPManager.h
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 Julian Dax. All rights reserved.
//

//! This class manages the aspects and insets them in the right spot
/*!
 This class does nearly all the work in AOPLib, the rest of the classes mainly just hold values.
 There sould only ever be one instance of this class alive.
 */ 

#import <Foundation/Foundation.h>
#import "ObjC/runtime.h"
#import <objc/message.h>


#import "AOPClass.h"
#import "AOPMethod.h"
#import "AOPAspect.h"
#import "ffi.h"

static NSMutableDictionary* classes; /*!< This holds all the classes which have join points*/

@interface AOPManager : NSObject {
    
}
//! Insets an aspect before the method of a given class.
/*!
 One can add several aspects before one method. Aspects are executed in the order they are added.
 If one aspect returns a value which is not nil, the execurion of all the other aspects and the 
 original method is skipped and the value returned by the aspect is returned by the method.
 @param theAspect The aspect to execute before the method is executed
 @param method The method before which the aspect should be executed
 @param class The class which contains the method before which the aspect should be executed
 */ 
-(void)insertAspect:(Aspect)theAspect beforeMethod:(SEL)method ofClass:(Class)class;

//! Insets an aspect after the method of a given class.
/*!
 One can add several aspects after one method. Aspects are executed in the order they are added.

 @param theAspect The aspect to execute after the method is executed
 @param method The method after which the aspect should be executed
 @param class The class which contains the method after which the aspect should be executed
 */ 
-(void)insertAspect:(Aspect)theAspect afterMethod:(SEL)method ofClass:(Class)class;

@end
