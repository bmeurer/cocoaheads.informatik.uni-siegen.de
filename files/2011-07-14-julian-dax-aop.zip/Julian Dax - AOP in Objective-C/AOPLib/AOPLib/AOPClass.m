//
//  AOPClass.m
//  AOPLib
//
//  Created by Julian Dax on 03.05.11.
//  Copyright 2011 Julian Dax. All rights reserved.
//

#import "AOPClass.h"


@implementation AOPClass

- (id)init {
    self = [super init];
    if (self) {
        methods = [[NSMutableDictionary alloc] init];
    }
    return self;
}
- (void)dealloc {
    [methods release];
    [super dealloc];
}
-(void)addMethod:(AOPMethod*)method forSelector:(SEL)selector{
    [methods setObject:method forKey:NSStringFromSelector(selector)];
}


-(AOPMethod*)methodForSelector:(SEL)selector {
    return [methods objectForKey: NSStringFromSelector(selector)];
}
@end
