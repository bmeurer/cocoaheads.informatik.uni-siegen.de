//
//  AOPInterceptorInfo.m
//  InnoliFoundation
//
//  Created by Szilveszter Molnar on 1/7/11.
//  Copyright 2011 Innoli Kft. All rights reserved.
//

#import "AOPInterceptorInfo.h"


@implementation AOPInterceptorInfo

@synthesize interceptedSelector;
@synthesize interceptorSelector;
@synthesize interceptorTarget;

@end

